
#include "SAT.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int nsize=0;//V value
char c;
int statu=0;// start

int i=0;
int j=0;
int nstart=0;
int nend=0;
int lstart=0;
int lend=0;
int **metrixD,**metrixX;

int vc_sat_zchaff(int V,int k,int **E);

int main()
{
    char number[10];
	number[0]='\0';
	char standnumber[10];
	standnumber[0]='\0';
	while(!feof(stdin)&&statu!=13){
		c=getc(stdin);
		switch(c){
			case 'V':
			case 'v':statu=1; break;
			case 'E':
			case 'e':if(statu!=-1){statu=5;} break;
			case '0':
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
				if(statu==2||statu==8||statu==10) {
					i=0 ;
					while(number[i]!='\0'){i++;}
					number[i]=c;
					number[i+1]='\0';
					statu=statu+1;
				}
				else if(statu==3||statu==9||statu==11) {
					i=0 ;
					while(number[i]!='\0'){i++;}
					number[i]=c;
					number[i+1]='\0';
				}
				break;
			case ' ':
            case '=':
			case '\n':
                if(statu==1||statu==5) {
                    statu=statu+1;
                }
                else if(statu==3){
					nsize=atoi(number);
					metrixD=(int**)malloc(nsize*sizeof(int*));
					for(i=0;i<nsize;i++) {
						metrixD[i]=(int*)malloc(nsize*sizeof(int));
						for(j=0;j<nsize;j++){
                            metrixD[i][j]=0;
						}
					}
					strcpy(number,standnumber);
					statu=4;
				}
				else if(statu==12){
                    for (i=1; i<=nsize; i++) {
                        if(vc_sat_zchaff(nsize,i,metrixD)==1){break;}
                    }
                    fprintf(stdout,"\n");fflush(stdout);
                    statu=13;
				}
				break;
			case '{':
				if(statu==6){
					statu=7;
				}break;
			case '}':
				if(statu==12)
				{
					statu=12;
				}
				break;
			case '<':if(statu==7){
				statu=8;
            }
				break;
			case '>':
				if(statu==11){
					nend=atoi(number);
					strcpy(number,standnumber);
					if(nstart > nsize-1 || nend > nsize-1){
						fprintf(stdout,"Error: <%d,%d> is out of range V %d\n",nstart,nend,nsize);fflush(stdout);
                        statu=-1;
                        break;
					}
					else{
						metrixD[nstart][nend]=1;
						metrixD[nend][nstart]=1;
					}
					statu=12;
				}
				break;
			case ',':
				if(statu==9){
					nstart=atoi(number);
					strcpy(number,standnumber);
					statu=10;
				}
				else if(statu==12){
					statu=8;
				}
				break;
                break;
			default:
                break;
		}
        
    }//end while
	return 0;
}

int vc_sat_zchaff(int V,int k,int **E){
    
    int i,j,p,q;
    int size;

    //xij=(i-1)*k+j
    SAT_Manager mgr = SAT_InitManager();
    if(V>2*k){size=V;}else{size=2*k;}
    SAT_SetNumVariables(mgr, k*V);
    int c[size];
    
    for(i=1;i<=k;i++){
        for(j=1;j<=V;j++){
            c[j-1]=((j-1)*k+i) *2;
        }
        SAT_AddClause(mgr, c, V);
        //c[] are the first rule
    }
    
    for(i=1;i<=V;i++){
        for(q=1;q<=k;q++){
            for(p=1;p<q;p++){
                c[0]=(((i-1)*k+p) *2) + 1;
                c[1]=(((i-1)*k+q) *2) + 1;
                SAT_AddClause(mgr, c, 2);
            }
        }
        
    }
    
    for(i=1;i<=k;i++){
        for(q=1;q<=V;q++){
            for(p=1;p<q;p++){
                c[0]=(((p-1)*k+i) *2) + 1;
                c[1]=(((q-1)*k+i) *2) + 1;
                SAT_AddClause(mgr, c, 2);
            }
        }
        
    }
    
    for(i=1;i<=V;i++){
        for(j=1;j<=i;j++){
            if(E[i-1][j-1]==1){
                for(p=1;p<=k;p++){
                    c[p-1]=(((i-1)*k+p) *2);
                }
                for(p=1;p<=k;p++){
                    c[k+p-1]=(((j-1)*k+p) *2);
                }
                SAT_AddClause(mgr, c, k*2);
            }
            
        }
    }
    int result = SAT_Solve(mgr);
    if(result == SATISFIABLE) {
        int n = SAT_NumVariables(mgr);
        for(i = 1; i <= n; i++) {
            if(SAT_GetVarAsgnment(mgr, i) == 1) {
                fprintf(stdout,"%d ",int((i-1)/k)); fflush(stdout);
            }
        }
    }
    else {
        return 0;
    }
    return 1;

}
